export {
  en,
} from './en'

export {
  ar,
} from './ar'
