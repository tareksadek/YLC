export default {
  USER_ID: process.env.EMAILJS_KEY,
  TEMPLATE_ID: process.env.EMAILJS_TEMPLATE,
}
